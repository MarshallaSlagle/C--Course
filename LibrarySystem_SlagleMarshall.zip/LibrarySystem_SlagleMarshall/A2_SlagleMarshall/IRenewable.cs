﻿using System;
namespace A2_SlagleMarshall
{
    public interface IRenewable
    {
        bool Renew();
    }
}
